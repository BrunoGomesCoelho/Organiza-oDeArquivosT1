#ifndef _READFIXO_H_
#define _READFIXO_H_

FILE *fixed_readDataBase(FILE *input, int *nregs, int *nfields);

#endif
