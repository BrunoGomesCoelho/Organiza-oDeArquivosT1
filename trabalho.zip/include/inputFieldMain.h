#ifndef _INPUTFIELDMAIN_H_
#define _INPUTFIELDMAIN_H_

#include <stdbool.h>

bool verifyInputDocument(char *doc);

bool verifyInputDateAndTime(char *date);

bool verifyInputTicket(char *ticket);

#endif
