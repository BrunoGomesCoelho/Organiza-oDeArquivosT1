#ifndef _READTAMANHO_H_
#define _READTAMANHO_H_
#include <utils.h>

FILE *size_readDataBase(FILE *input, int *nregs, int *nfields);

t_field readFieldindicadorTamanho(FILE *fp);

#endif
