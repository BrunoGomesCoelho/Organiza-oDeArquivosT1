#ifndef _PRINTREGCAMPOTAMANHO_H_
#define _PRINTREGCAMPOTAMANHO_H_

#include <stdio.h>

void size_printRecordField(FILE *fp, int n);

#endif
