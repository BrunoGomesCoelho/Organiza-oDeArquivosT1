#ifndef _SEARCHFIELDTAMANHO_H_
#define _SEARCHFIELDTAMANHO_H_

void size_searchField(FILE *fp, int n);

#endif
