#ifndef _SEARCHFIELDDELIMITADOR_H_
#define _SEARCHFIELDDELIMITADOR_H_

void delimiter_searchField(FILE *fp, int n);

#endif
