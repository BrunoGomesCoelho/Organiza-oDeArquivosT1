#ifndef _PRINTREGCAMPODELIMITADOR_H_
#define _PRINTREGCAMPODELIMITADOR_H_

#include <stdio.h>

void delimiter_printRecordField(FILE *fp, int n);

#endif
