#ifndef _PRINTREGFIELDMAIN_H_
#define _PRINTREGFIELDMAIN_H_

#include <utils.h>

void printRegFieldMain(t_field field);

#endif
