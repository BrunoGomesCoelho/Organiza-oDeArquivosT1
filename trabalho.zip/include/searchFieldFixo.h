#ifndef _SEARCHFIELDFIXO_H_
#define _SEARCHFIELDFIXO_H_

void fixed_searchField(FILE *fp, int n);

#endif
