#ifndef _PRINTREGCAMPOFIXO_H_
#define _PRINTREGCAMPOFIXO_H_

#include <stdio.h>

void fixed_printRecordField(FILE *fp, int n);

#endif
