#ifndef _READDELIMITADOR_H_
#define _READDELIMITADOR_H_

FILE *delimiter_readDataBase(FILE *input, int *nregs, int *nfields);

#endif
